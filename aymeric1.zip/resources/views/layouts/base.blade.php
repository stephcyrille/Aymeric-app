<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/customNav.css') }}" rel="stylesheet">
    <link href="{{ asset('DataTables/datatables.css') }}" rel="stylesheet" /> 	

    <!-- FontAwesome CSS -->
    <link href="{{ asset('bootstrap-4/css/bootstrap.css') }}" rel="stylesheet"/>
    <link href="{{ asset('fontawesome/css/all.css') }}" rel="stylesheet"/>

    <!-- JQuery Script -->
    <script src="{{ asset('jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('DataTables/datatables.js') }}"></script> 	
    
    @yield('customCSS')

    <style>
      .nav>li, .nav>li>a {
            position: relative;
            display: block;
            width: 100%;
        }     
        body{
          margin: 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
          font-size: 1.5rem;
          font-weight: 400;
          line-height: 1.5;
          color: #212529;
          text-align: left;
          background-color: #fff;
        }    
    </style>

</head>
<body>
<div id="viewport">
  <!-- Sidebar -->
  <div id="sidebar">
    <header>
      <a href="#">GMAO ASECNA</a>
    </header>
    <ul class="nav">
      <li>
        <a href="{{ route('home') }}">
          Accueil
        </a>
      </li>
      <li>
        <a href="{{ route('liste_taches') }}">
          Ordre de travail
        </a>
      </li>
      <li>
        <a href="{{ route('liste_equipements') }}">
          Equipements
        </a>
      </li>
      <li>
        <a href="#">
          Fiches de rapport
        </a>
      </li>
      <li>
        <a href="{{ route('liste_profiles') }}">
          Gestion des utilisateurs
        </a>
      </li>
      <li>
        <a href="{{ route('analytic') }}">
          Analytic
        </a>
      </li>
      <li>
        <a href="#">
          Paramètres
        </a>
      </li>
    </ul>
  </div>
  <!-- Content -->
  <div id="content">
    <nav class="navbar navbar-default">
      <div class="container-fluid">
        <ul class="nav navbar-nav navbar-right">
          <li>
            <a href="#"><i class="zmdi zmdi-notifications text-danger"></i>
            </a>
          </li>
          <li>
            <a href="#">
              <i class="fa fa-user"></i>
              Test User
            </a>
          </li>
        </ul>
      </div>
    </nav>
    <div class="container-fluid">
      @yield('content')
    </div>
  </div>
</div>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>

    @yield('customJS')
</body>
</html>
