<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="offset-1 col-10 card" style="padding: 10px 20px">
          <h2 style="padding-top: 40px; padding-bottom: 40px; text-transform: uppercase">Liste des tâches</h2>
          <div class="row">
            <div class="col-3">
                <a href="<?php echo e(route('ajout_tache')); ?>" class="btn btn-primary" style="padding: 10px">
                  <i class="fa fa-plus"></i>
                  Ajouter une nouvelle tâche
                </a>
            </div>
          </div>
          <div class="row">
            <div class="card-body">
              <table class="table table-striped">
                <thead>
                  <td>Libelle</td>
                  <td>Equipement</td>
                  <td>Date debut</td>
                  <td>Date fin</td>
                  <td>Responsable</td>
                  <td>Actions</td>
                </thead>
                <tbody>
                  <tr>
                      
                      
                      
                      
                      
                      
                      <?php $__currentLoopData = $taches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td> <?php echo e($item->libelle); ?> </td>
                        <td> <?php echo e($item->equipement_id); ?> </td>
                        <td> <?php echo e($item->date_debut); ?> </td>
                        <td> <?php echo e($item->date_fin); ?> </td>
                        <td> <?php echo e($item->responsable_id); ?> </td>
                        <td>
                          <div class="btn-group">
                            <button class="btn btn-outline-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Actions
                            </button>
                            <div class="dropdown-menu">
                              <a href="#" class="dropdown-item">
                                Visualiser
                              </a>
                              <a href="#" class="dropdown-item">
                                Supprimer
                              </a>
                            </div>
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>