<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="offset-1 col-10 card" style="padding: 10px 20px">
          <h2 style="padding-top: 40px; padding-bottom: 40px; text-transform: uppercase">Liste des équipements</h2>
          <div class="row">
            <div class="col-3">
                <a href="<?php echo e(route('ajout_equipement')); ?>" class="btn btn-primary" style="padding: 10px">
                  <i class="fa fa-plus"></i>
                  Ajouter un équipement
                </a>
            </div>
          </div>
          <div class="row">
            <div class="card-body">
              <table class="table table-striped">
                <thead>
                  <td scope="col">Nom</td>
                  <td scope="col">Fabriquant</td>
                  <td scope="col">numero de serie</td>
                  <td scope="col">Actions</td>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $equipements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td> <?php echo e($item->nom); ?> </td>
                      <td> <?php echo e($item->fabriquant); ?> </td>
                      <td> <?php echo e($item->numero_serie); ?> </td>
                      <td>
                        <div class="btn-group">
                          <button class="btn btn-outline-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Actions
                          </button>
                          <div class="dropdown-menu">
                            <a href="#" class="dropdown-item">
                              Visualiser
                            </a>
                            <a href="#" class="dropdown-item">
                              Supprimer
                            </a>
                          </div>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>