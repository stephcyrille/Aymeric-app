<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="offset-1 col-10 card" style="padding: 10px 20px">
          <h2 style="padding-top: 40px; padding-bottom: 40px; text-transform: uppercase">Liste des utilisateurs</h2>
          <div class="row">
            
          </div>
          <div class="row">
            <div class="card-body">
              <table class="table table-striped">
                <thead>
                  <td scope="col">Nom et prénom</td>
                  <td scope="col">Téléphone</td>
                  <td scope="col">Adresse</td>
                  <td scope="col">Role</td>
                  <td scope="col">Actions</td>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td> <?php echo e($item->nom.' '.$item->prenom); ?> </td>
                      <td> <?php echo e($item->telephone); ?> </td>
                      <td> <?php echo e($item->adresse); ?> </td>
                      <td> <?php echo e($item->role); ?> </td>
                      <td>
                        <div class="btn-group">
                          <button class="btn btn-outline-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Actions
                          </button>
                          <div class="dropdown-menu">
                            <a href="<?php echo e(route('modifier_profile', $item->id)); ?>" class="dropdown-item">
                              Modifier
                            </a>
                            <a href="#" class="dropdown-item">
                              Supprimer
                            </a>
                          </div>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
    </div>    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>