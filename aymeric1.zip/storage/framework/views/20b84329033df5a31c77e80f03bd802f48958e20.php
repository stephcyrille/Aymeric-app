<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="col">
        <h3>Tous les Services</h3>
            <a href="<?php echo e(route('add_service')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i>
                Ajouter un service
            </a>
            <span class="mb-0 mt-6" id="infoAlert"></span>
            <div class="card card-small mt-4 p-4 mb-4"> 
              
                <table class="table table-striped">

                    <thead>
                      <tr>
                        <th scope="col">Nom</th>
                        <th scope="col">Code</th>
                        <th scope="col">Actions</th>
                      </tr>
                    </thead>

                    <tbody>
                      <?php $__currentLoopData = $all_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td> <?php echo e($item->nom); ?></td>
                          <td> <?php echo e($item->code); ?> </td>
                          <td> 
                            <div class="btn-group">
                              <button class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true", aria-expanded="false">
                                Action
                              </button>
                              <div class="dropdown-menu">
                                <a href="/courrier/single/<?php echo e($item->id); ?>/valid" class="dropdown-item">
                                  Consulter
                                </a>
                                <a href="/courrier/single/<?php echo e($item->id); ?>/delete" class="dropdown-item">
                                  Supprimer
                                </a>
                              </div>
                            </div>
                          </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </tbody>
                </table>
    
    
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>