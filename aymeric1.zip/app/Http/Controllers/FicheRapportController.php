<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FicheRapportController extends Controller
{
    //
}
